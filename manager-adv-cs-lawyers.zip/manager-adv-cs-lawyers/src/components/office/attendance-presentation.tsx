import { useState, type ReactElement } from 'react';
import { RefreshCw, FolderOpen, Play, Upload, Check, ChevronRight, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '@/components/ui/command';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { AnaliseDocumento } from '@/components/analise-documento';
import { ChecklistCorrection } from './checklist-correction';
import { actionLabels, type AttendanceAction } from './attendance-actions';
import { type programmed } from '@/lib/atendimento';
import type { Conversa } from '@/lib/mock-data';
import type { OfficeCase } from '@/lib/office';
import { AttendanceProjuris } from './attendance-projuris';

export function Hint({ label, children }: { label: string; children: ReactElement }) {
  return <TooltipProvider delayDuration={250}><Tooltip><TooltipTrigger asChild>{children}</TooltipTrigger><TooltipContent className="max-w-72 whitespace-normal">{label}</TooltipContent></Tooltip></TooltipProvider>;
}

export function AttendanceMenu({ open, onOpenChange, c, busy, primary, choose, initialSearch }: {
  open: boolean; onOpenChange: (open: boolean) => void; c: Conversa; busy: boolean;
  primary: AttendanceAction[]; choose: (key: string, content: string) => void; initialSearch: string;
}) {
  const actions = [...primary, ...(Object.keys(actionLabels) as AttendanceAction[]).filter(k => !primary.includes(k))];
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="max-w-md gap-0 overflow-hidden p-0"><DialogHeader className="sr-only"><DialogTitle>Ações da etapa</DialogTitle></DialogHeader><Command key={initialSearch}><CommandInput aria-label="Buscar ação" placeholder="Buscar ação…" defaultValue={initialSearch}/><CommandList className="max-h-[60vh]"><CommandEmpty>Nenhuma ação encontrada.</CommandEmpty><CommandGroup heading="Ações desta etapa">{actions.map(k => {
    const reason = busy ? 'Aguarde a ação atual' : k === 'retorno' && c.etapa !== 'ativo' ? 'Disponível para cliente ativo' : '';
    return <CommandItem key={k} value={`${k} ${actionLabels[k]}`} disabled={!!reason} onSelect={() => choose(k, '')}><ChevronRight/><span className="min-w-0"><span className="block">{k === 'provas' ? 'Pedir lista de provas' : actionLabels[k]}</span>{reason && <span className="block text-xs text-muted-foreground">{reason}</span>}</span></CommandItem>;
  })}</CommandGroup></CommandList></Command></DialogContent></Dialog>;
}

export function AttendanceDetails({ c, update, summary, refreshSummary, busy, jobs, updateContract, initialTab = 'cliente', work, loadingRecords, recordsError, refreshRecords }: {
  c: Conversa; update: (fn: (c: Conversa) => Conversa) => void; summary: string; refreshSummary: () => void;
  busy: boolean; jobs: ReturnType<typeof programmed>; updateContract: () => void; initialTab?: string;
  work: OfficeCase; loadingRecords: boolean; recordsError: boolean; refreshRecords: () => Promise<unknown>;
}) {
  const [expanded, setExpanded] = useState(false);
  const recebidos = c.documentos.filter(d => d.recebido).length;
  const signedAt = c.timeline.find(t => /contrato assinado/i.test(t.evento))?.data;
  const signedDate = signedAt && (Number.isFinite(Date.parse(signedAt)) && signedAt.includes('T') ? new Date(signedAt).toLocaleDateString('pt-BR') : signedAt);
  return <aside aria-label="Detalhes do atendimento" className="flex h-full min-h-0 min-w-0 flex-col border-l bg-card"><Tabs defaultValue={initialTab} className="flex min-h-0 flex-1 flex-col gap-0"><TabsList className="h-auto w-full shrink-0 justify-start gap-0 rounded-none border-b bg-transparent p-0"><TabsTrigger value="cliente" className="h-12 min-w-0 flex-1 rounded-none px-2 text-xs data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Cliente</TabsTrigger><TabsTrigger value="docs" className="h-12 min-w-0 flex-1 rounded-none px-2 text-xs data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Documentos</TabsTrigger><TabsTrigger value="consulta" className="h-12 min-w-0 flex-1 whitespace-normal rounded-none px-2 text-xs leading-tight data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">Consulta e histórico</TabsTrigger><TabsTrigger value="projuris" className="h-12 min-w-0 flex-1 rounded-none px-1 text-xs data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none">ProJuris</TabsTrigger></TabsList><div className="min-h-0 flex-1 overflow-y-auto [overflow-wrap:anywhere]">
    <TabsContent value="cliente" className="m-0 space-y-5 p-4"><section className="border-b pb-4"><div className="mb-2 flex items-center justify-between"><h3 className="font-sans text-xs font-semibold">Resumo da IA</h3><Hint label="Atualizar resumo"><Button variant="ghost" size="icon" className="size-7" aria-label="Atualizar resumo da IA" disabled={busy} onClick={refreshSummary}><RefreshCw className="size-3.5"/></Button></Hint></div><p className={expanded ? 'text-xs leading-relaxed text-muted-foreground' : 'line-clamp-3 text-xs leading-relaxed text-muted-foreground'}>{summary || `${c.nome} · ${c.documentos.filter(d => !d.recebido).length} documentos pendentes.`}</p><Button variant="link" className="h-auto p-0 text-xs" onClick={() => setExpanded(v => !v)}>{expanded ? 'Ver menos' : 'Ver mais'}</Button></section>
    <dl className="grid grid-cols-[76px_minmax(0,1fr)] gap-x-3 gap-y-2 text-xs"><dt className="text-muted-foreground">Nome</dt><dd>{c.nome}</dd><dt className="text-muted-foreground">CPF</dt><dd>{c.cpf}</dd><dt className="text-muted-foreground">Telefone</dt><dd>{c.telefone}</dd><dt className="text-muted-foreground">Atendimento</dt><dd>{c.atendimento}</dd></dl>
    <div className="flex flex-wrap items-center gap-1 border-y py-3 text-xs"><Hint label="Gerado → Enviado → Visualizado → Assinado"><span className={c.contrato === 'assinado' ? 'flex items-center gap-1 text-success' : 'text-muted-foreground'}>{c.contrato === 'assinado' ? <>Assinado{signedDate ? ` em ${signedDate}` : ''}<Check className="size-3"/></> : c.contrato ? c.contrato.charAt(0).toUpperCase() + c.contrato.slice(1) : 'Contrato não gerado'}</span></Hint>{c.contrato && c.contrato !== 'assinado' && <><span className="text-muted-foreground">·</span><Button variant="link" className="h-auto p-0 text-xs" onClick={updateContract}>Atualizar status</Button></>}</div>
    <a href="#" onClick={e => { e.preventDefault(); toast.info('Abriria a pasta no Google Drive (demonstração)'); }} title={`${c.nome} – ${c.atendimento} › Start`} className="flex min-w-0 items-center gap-2 text-xs text-primary"><FolderOpen className="size-4 shrink-0"/><span className="truncate">{c.nome} – {c.atendimento} › Start</span></a>
    <section><h3 className="mb-2 font-sans text-xs font-semibold">Processos ({c.processos.length})</h3>{!c.processos.length && <p className="text-xs text-muted-foreground">Nenhum processo vinculado.</p>}{c.processos.map(p => <div key={p.cnj} className="space-y-1 border-b py-3 text-xs"><p className="flex items-start gap-1.5 font-mono"><FileText className="size-3.5 shrink-0 text-muted-foreground"/>{p.cnj}</p><p className="text-muted-foreground">{p.vara}</p><p>{p.status}</p><p className={p.homologado ? 'text-success' : 'text-muted-foreground'}>{p.homologado ? 'Homologado' : 'Não homologado'}</p></div>)}</section>
    <details className="border-t pt-3"><summary className="cursor-pointer text-xs text-muted-foreground">{jobs.length} automações programadas</summary><div className="space-y-2 pt-3">{jobs.map(j => <p key={j.key} className="text-xs text-muted-foreground">{j.title} · {new Date(j.when).toLocaleString('pt-BR')} · demonstração</p>)}{!jobs.length && <p className="text-xs text-muted-foreground">Nenhum lembrete programado.</p>}</div></details></TabsContent>
    <TabsContent value="docs" className="m-0 p-4"><p className="mb-2 text-xs text-muted-foreground">{recebidos} de {c.documentos.length} recebidos</p><Progress value={c.documentos.length ? recebidos / c.documentos.length * 100 : 0} className="mb-4 h-1"/><ChecklistCorrection c={c} update={update}/><AnaliseDocumento key={c.id} c={c} update={update}/></TabsContent>
    <TabsContent value="consulta" className="m-0 space-y-5 p-4">{c.consulta ? <><div className="flex items-center gap-2 border-b pb-3"><Button size="icon" variant="ghost" aria-label="Reproduzir gravação"><Play/></Button><Progress value={33} className="h-1 flex-1"/><span className="text-xs text-muted-foreground">{c.consulta.duracao}</span></div><section><h3 className="mb-2 font-sans text-xs font-semibold">Resumo da consulta</h3><p className="text-xs leading-relaxed">{c.consulta.resumo}</p></section><section><h3 className="mb-2 font-sans text-xs font-semibold">Transcrição</h3><p className="whitespace-pre-wrap text-xs leading-relaxed">{c.consulta.transcricao}</p></section></> : <section className="space-y-2"><p className="text-xs text-muted-foreground">Consulta ainda não registrada.</p><Button variant="outline" className="h-auto w-full whitespace-normal text-xs" onClick={() => toast.success('Transcrição enviada (demonstração)')}><Upload/>Enviar transcrição</Button><Button variant="outline" className="h-auto w-full whitespace-normal text-xs" onClick={() => toast.success('Sumarização enviada (demonstração)')}><Upload/>Enviar sumarização</Button></section>}<section className="border-t pt-4"><h3 className="mb-4 font-sans text-xs font-semibold">Histórico</h3><ol className="ml-1 space-y-4 border-l pl-4">{c.timeline.map(t => <li key={t.data + t.evento}><p className="text-[10px] text-muted-foreground">{t.data}</p><p className="text-xs leading-relaxed">{t.evento}</p></li>)}</ol></section></TabsContent>
    <TabsContent value="projuris" className="m-0"><AttendanceProjuris c={c} work={work} loading={loadingRecords} error={recordsError} refresh={refreshRecords}/></TabsContent>
  </div></Tabs></aside>;
}